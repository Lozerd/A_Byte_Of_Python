import time
from memory_profiler import memory_usage

start = time.time()


def piphaghor(t, need):
    for n in range(1, t + 1):
        for m in range(1, t + 1):
            primitive = (m ** 2 - n ** 2, 2 * m * n, m ** 2 + n ** 2)
            p = primitive
            if p[0] > 0:
                if p[0] ** 2 + p[1] ** 2 == p[2] ** 2:
                    total = sum(list(primitive))
                    if total == need:
                        print(primitive)


piphaghor(int(input('Введите длину цикла: ')), int(input('Введите нужную сумму пифагоровой тройки: ')))
print(time.time() - start)
print(memory_usage())

# numbers = [1, 2, 3]
# numsum = sum(list(numbers))
# print(numsum)
