class Person:
    def sayHi(self):
        print('Привет! Как дела?')


p = Person()
p.sayHi()
