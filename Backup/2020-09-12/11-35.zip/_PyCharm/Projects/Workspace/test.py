a = [x for x in range(1, 101, 1) if x % 7 == 0]
print(a)
