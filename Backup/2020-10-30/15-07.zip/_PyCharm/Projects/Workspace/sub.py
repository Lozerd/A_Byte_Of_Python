email = 'Python изучают все больше людей'  # input()
lists = [email]

# for i in range(len(email)):
#     if list[i] == ' ':
#         email[i:i+1].upper()
