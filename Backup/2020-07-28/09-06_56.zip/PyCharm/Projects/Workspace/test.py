def array(n):
    arr =[]
    for i in range (n):
        arr.append(input('Введите элемент: '))
        print(arr)
    # arr = [input('Введите элемент: ') for i in range(n)]
    # print(arr)
    else:
        print('Программа закрывается')
        input('Напишите выход: ')

array(int(input('Введите длину списка: ')))
