from mymodule import sayhi, __version__

sayhi()
print('Версия', __version__)