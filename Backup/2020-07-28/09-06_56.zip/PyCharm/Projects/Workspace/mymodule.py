def sayhi():
    print('Привет! Это говорит мой модуль.')

__version__ = '0.1'

# конец модуля mymodule.py
# H:/PyCharm/Projects
