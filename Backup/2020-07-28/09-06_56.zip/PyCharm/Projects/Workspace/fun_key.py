def func(a, b=5, c=10):
    print('a is ', a, ', b is ', b, ' and c is ', c, sep='')


func(3, 7, 2)
