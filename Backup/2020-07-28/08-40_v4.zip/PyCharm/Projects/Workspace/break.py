while True:
    way = input('Enter some text to know its length:')
    if way == 'exit':
        break
    print('Length of your sentence is:', len(way))
print('Ending session')